export type task={
    sr?:number,
    title?:string,
    des?:string,
    addOnDate?:Date,
    date?:Date,
    priorityLevel?:string;
    category?:string;
    completed? : boolean ;

    
}