export type userprofile={
    firstName?:string,
    lastName?:string,
    contact?:string,
    uploadImage?:string

    
}